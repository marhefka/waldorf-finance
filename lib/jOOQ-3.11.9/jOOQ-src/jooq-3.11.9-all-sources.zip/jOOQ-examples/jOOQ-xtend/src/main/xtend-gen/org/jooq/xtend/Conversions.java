/**
 * Copyright (c) 2009-2016, Data Geekery GmbH (http://www.datageekery.com)
 * All rights reserved.
 *
 * This work is dual-licensed
 * - under the Apache Software License 2.0 (the "ASL")
 * - under the jOOQ License and Maintenance Agreement (the "jOOQ License")
 * =============================================================================
 * You may choose which license applies to you:
 *
 * - If you're using this work with Open Source databases, you may choose
 *   either ASL or jOOQ License.
 * - If you're using this work with at least one commercial database, you must
 *   choose jOOQ License
 *
 * For more information, please visit http://www.jooq.org/licenses
 *
 * Apache Software License 2.0:
 * -----------------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * jOOQ License and Maintenance Agreement:
 * -----------------------------------------------------------------------------
 * Data Geekery grants the Customer the non-exclusive, timely limited and
 * non-transferable license to install and use the Software under the terms of
 * the jOOQ License and Maintenance Agreement.
 *
 * This library is distributed with a LIMITED WARRANTY. See the jOOQ License
 * and Maintenance Agreement for more details: http://www.jooq.org/licensing
 */
package org.jooq.xtend;

import java.math.BigDecimal;
import javax.annotation.Generated;
import org.jooq.Condition;
import org.jooq.Field;
import org.jooq.QuantifiedSelect;
import org.jooq.Record;
import org.jooq.Record1;
import org.jooq.Record10;
import org.jooq.Record11;
import org.jooq.Record12;
import org.jooq.Record13;
import org.jooq.Record14;
import org.jooq.Record15;
import org.jooq.Record16;
import org.jooq.Record17;
import org.jooq.Record18;
import org.jooq.Record19;
import org.jooq.Record2;
import org.jooq.Record20;
import org.jooq.Record21;
import org.jooq.Record22;
import org.jooq.Record3;
import org.jooq.Record4;
import org.jooq.Record5;
import org.jooq.Record6;
import org.jooq.Record7;
import org.jooq.Record8;
import org.jooq.Record9;
import org.jooq.Row1;
import org.jooq.Row10;
import org.jooq.Row11;
import org.jooq.Row12;
import org.jooq.Row13;
import org.jooq.Row14;
import org.jooq.Row15;
import org.jooq.Row16;
import org.jooq.Row17;
import org.jooq.Row18;
import org.jooq.Row19;
import org.jooq.Row2;
import org.jooq.Row20;
import org.jooq.Row21;
import org.jooq.Row22;
import org.jooq.Row3;
import org.jooq.Row4;
import org.jooq.Row5;
import org.jooq.Row6;
import org.jooq.Row7;
import org.jooq.Row8;
import org.jooq.Row9;
import org.jooq.RowN;
import org.jooq.Select;
import org.jooq.Table;
import org.jooq.impl.DSL;

/**
 * jOOQ type conversions used to enhance the jOOQ Java API with Xtend operators.
 *
 * @author Lukas Eder
 * @see <a href="http://www.eclipse.org/xtend/documentation.html#operators">http://www.eclipse.org/xtend/documentation.html#operators</a>
 */
@Generated("This class was generated using jOOQ-tools")
@SuppressWarnings("all")
public class Conversions {
  public static <T extends Object> Condition operator_or(final Condition c1, final Condition c2) {
    return c1.or(c2);
  }

  public static <T extends Object> Condition operator_and(final Condition c1, final Condition c2) {
    return c1.and(c2);
  }

  public static <T extends Object> Condition operator_tripleEquals(final Field<T> f1, final T f2) {
    return f1.eq(f2);
  }

  public static <T extends Object> Condition operator_tripleEquals(final Field<T> f1, final Field<T> f2) {
    return f1.eq(f2);
  }

  public static <T extends Object> Condition operator_tripleEquals(final Field<T> f1, final Select<? extends Record1<T>> f2) {
    return f1.eq(f2);
  }

  public static <T extends Object> Condition operator_tripleEquals(final Field<T> f1, final QuantifiedSelect<? extends Record1<T>> f2) {
    return f1.eq(f2);
  }

  public static Condition operator_tripleEquals(final RowN r1, final RowN r2) {
    return r1.eq(r2);
  }

  public static Condition operator_tripleEquals(final RowN r1, final Record r2) {
    return r1.eq(r2);
  }

  public static Condition operator_tripleEquals(final RowN r1, final Select<? extends Record> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object> Condition operator_tripleEquals(final Row1<T1> r1, final Row1<T1> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object> Condition operator_tripleEquals(final Row1<T1> r1, final Record1<T1> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object> Condition operator_tripleEquals(final Row1<T1> r1, final Select<? extends Record1<T1>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_tripleEquals(final Row2<T1, T2> r1, final Row2<T1, T2> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_tripleEquals(final Row2<T1, T2> r1, final Record2<T1, T2> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_tripleEquals(final Row2<T1, T2> r1, final Select<? extends Record2<T1, T2>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_tripleEquals(final Row3<T1, T2, T3> r1, final Row3<T1, T2, T3> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_tripleEquals(final Row3<T1, T2, T3> r1, final Record3<T1, T2, T3> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_tripleEquals(final Row3<T1, T2, T3> r1, final Select<? extends Record3<T1, T2, T3>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_tripleEquals(final Row4<T1, T2, T3, T4> r1, final Row4<T1, T2, T3, T4> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_tripleEquals(final Row4<T1, T2, T3, T4> r1, final Record4<T1, T2, T3, T4> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_tripleEquals(final Row4<T1, T2, T3, T4> r1, final Select<? extends Record4<T1, T2, T3, T4>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_tripleEquals(final Row5<T1, T2, T3, T4, T5> r1, final Row5<T1, T2, T3, T4, T5> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_tripleEquals(final Row5<T1, T2, T3, T4, T5> r1, final Record5<T1, T2, T3, T4, T5> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_tripleEquals(final Row5<T1, T2, T3, T4, T5> r1, final Select<? extends Record5<T1, T2, T3, T4, T5>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_tripleEquals(final Row6<T1, T2, T3, T4, T5, T6> r1, final Row6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_tripleEquals(final Row6<T1, T2, T3, T4, T5, T6> r1, final Record6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_tripleEquals(final Row6<T1, T2, T3, T4, T5, T6> r1, final Select<? extends Record6<T1, T2, T3, T4, T5, T6>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_tripleEquals(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Row7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_tripleEquals(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Record7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_tripleEquals(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Select<? extends Record7<T1, T2, T3, T4, T5, T6, T7>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_tripleEquals(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_tripleEquals(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Record8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_tripleEquals(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Select<? extends Record8<T1, T2, T3, T4, T5, T6, T7, T8>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_tripleEquals(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_tripleEquals(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_tripleEquals(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Select<? extends Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_tripleEquals(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_tripleEquals(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_tripleEquals(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Select<? extends Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_tripleEquals(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_tripleEquals(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_tripleEquals(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Select<? extends Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_tripleEquals(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_tripleEquals(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_tripleEquals(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Select<? extends Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_tripleEquals(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_tripleEquals(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_tripleEquals(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Select<? extends Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_tripleEquals(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_tripleEquals(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_tripleEquals(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Select<? extends Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_tripleEquals(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_tripleEquals(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_tripleEquals(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Select<? extends Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_tripleEquals(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_tripleEquals(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_tripleEquals(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Select<? extends Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_tripleEquals(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_tripleEquals(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_tripleEquals(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Select<? extends Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_tripleEquals(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_tripleEquals(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_tripleEquals(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Select<? extends Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_tripleEquals(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_tripleEquals(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_tripleEquals(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Select<? extends Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_tripleEquals(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_tripleEquals(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_tripleEquals(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Select<? extends Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_tripleEquals(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_tripleEquals(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_tripleEquals(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Select<? extends Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21>> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_tripleEquals(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_tripleEquals(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.eq(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_tripleEquals(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Select<? extends Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22>> r2) {
    return r1.eq(r2);
  }

  public static <T extends Object> Condition operator_tripleNotEquals(final Field<T> f1, final T f2) {
    return f1.ne(f2);
  }

  public static <T extends Object> Condition operator_tripleNotEquals(final Field<T> f1, final Field<T> f2) {
    return f1.ne(f2);
  }

  public static <T extends Object> Condition operator_tripleNotEquals(final Field<T> f1, final Select<? extends Record1<T>> f2) {
    return f1.ne(f2);
  }

  public static <T extends Object> Condition operator_tripleNotEquals(final Field<T> f1, final QuantifiedSelect<? extends Record1<T>> f2) {
    return f1.ne(f2);
  }

  public static <T1 extends Object> Condition operator_tripleNotEquals(final Row1<T1> r1, final Row1<T1> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object> Condition operator_tripleNotEquals(final Row1<T1> r1, final Record1<T1> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object> Condition operator_tripleNotEquals(final Row1<T1> r1, final Select<? extends Record1<T1>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_tripleNotEquals(final Row2<T1, T2> r1, final Row2<T1, T2> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_tripleNotEquals(final Row2<T1, T2> r1, final Record2<T1, T2> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_tripleNotEquals(final Row2<T1, T2> r1, final Select<? extends Record2<T1, T2>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_tripleNotEquals(final Row3<T1, T2, T3> r1, final Row3<T1, T2, T3> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_tripleNotEquals(final Row3<T1, T2, T3> r1, final Record3<T1, T2, T3> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_tripleNotEquals(final Row3<T1, T2, T3> r1, final Select<? extends Record3<T1, T2, T3>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_tripleNotEquals(final Row4<T1, T2, T3, T4> r1, final Row4<T1, T2, T3, T4> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_tripleNotEquals(final Row4<T1, T2, T3, T4> r1, final Record4<T1, T2, T3, T4> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_tripleNotEquals(final Row4<T1, T2, T3, T4> r1, final Select<? extends Record4<T1, T2, T3, T4>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_tripleNotEquals(final Row5<T1, T2, T3, T4, T5> r1, final Row5<T1, T2, T3, T4, T5> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_tripleNotEquals(final Row5<T1, T2, T3, T4, T5> r1, final Record5<T1, T2, T3, T4, T5> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_tripleNotEquals(final Row5<T1, T2, T3, T4, T5> r1, final Select<? extends Record5<T1, T2, T3, T4, T5>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_tripleNotEquals(final Row6<T1, T2, T3, T4, T5, T6> r1, final Row6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_tripleNotEquals(final Row6<T1, T2, T3, T4, T5, T6> r1, final Record6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_tripleNotEquals(final Row6<T1, T2, T3, T4, T5, T6> r1, final Select<? extends Record6<T1, T2, T3, T4, T5, T6>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_tripleNotEquals(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Row7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_tripleNotEquals(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Record7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_tripleNotEquals(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Select<? extends Record7<T1, T2, T3, T4, T5, T6, T7>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_tripleNotEquals(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_tripleNotEquals(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Record8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_tripleNotEquals(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Select<? extends Record8<T1, T2, T3, T4, T5, T6, T7, T8>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_tripleNotEquals(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_tripleNotEquals(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_tripleNotEquals(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Select<? extends Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_tripleNotEquals(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_tripleNotEquals(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_tripleNotEquals(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Select<? extends Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_tripleNotEquals(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_tripleNotEquals(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_tripleNotEquals(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Select<? extends Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_tripleNotEquals(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_tripleNotEquals(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_tripleNotEquals(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Select<? extends Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_tripleNotEquals(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_tripleNotEquals(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_tripleNotEquals(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Select<? extends Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_tripleNotEquals(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_tripleNotEquals(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_tripleNotEquals(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Select<? extends Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_tripleNotEquals(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_tripleNotEquals(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_tripleNotEquals(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Select<? extends Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_tripleNotEquals(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_tripleNotEquals(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_tripleNotEquals(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Select<? extends Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_tripleNotEquals(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_tripleNotEquals(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_tripleNotEquals(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Select<? extends Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_tripleNotEquals(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_tripleNotEquals(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_tripleNotEquals(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Select<? extends Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_tripleNotEquals(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_tripleNotEquals(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_tripleNotEquals(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Select<? extends Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_tripleNotEquals(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_tripleNotEquals(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_tripleNotEquals(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Select<? extends Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_tripleNotEquals(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_tripleNotEquals(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_tripleNotEquals(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Select<? extends Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21>> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_tripleNotEquals(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_tripleNotEquals(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.ne(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_tripleNotEquals(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Select<? extends Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22>> r2) {
    return r1.ne(r2);
  }

  public static <T extends Object> Condition operator_lessThan(final Field<T> f1, final T f2) {
    return f1.lt(f2);
  }

  public static <T extends Object> Condition operator_lessThan(final Field<T> f1, final Field<T> f2) {
    return f1.lt(f2);
  }

  public static <T extends Object> Condition operator_lessThan(final Field<T> f1, final Select<? extends Record1<T>> f2) {
    return f1.lt(f2);
  }

  public static <T extends Object> Condition operator_lessThan(final Field<T> f1, final QuantifiedSelect<? extends Record1<T>> f2) {
    return f1.lt(f2);
  }

  public static <T1 extends Object> Condition operator_lessThan(final Row1<T1> r1, final Row1<T1> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object> Condition operator_lessThan(final Row1<T1> r1, final Record1<T1> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object> Condition operator_lessThan(final Row1<T1> r1, final Select<? extends Record1<T1>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_lessThan(final Row2<T1, T2> r1, final Row2<T1, T2> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_lessThan(final Row2<T1, T2> r1, final Record2<T1, T2> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_lessThan(final Row2<T1, T2> r1, final Select<? extends Record2<T1, T2>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_lessThan(final Row3<T1, T2, T3> r1, final Row3<T1, T2, T3> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_lessThan(final Row3<T1, T2, T3> r1, final Record3<T1, T2, T3> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_lessThan(final Row3<T1, T2, T3> r1, final Select<? extends Record3<T1, T2, T3>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_lessThan(final Row4<T1, T2, T3, T4> r1, final Row4<T1, T2, T3, T4> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_lessThan(final Row4<T1, T2, T3, T4> r1, final Record4<T1, T2, T3, T4> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_lessThan(final Row4<T1, T2, T3, T4> r1, final Select<? extends Record4<T1, T2, T3, T4>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_lessThan(final Row5<T1, T2, T3, T4, T5> r1, final Row5<T1, T2, T3, T4, T5> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_lessThan(final Row5<T1, T2, T3, T4, T5> r1, final Record5<T1, T2, T3, T4, T5> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_lessThan(final Row5<T1, T2, T3, T4, T5> r1, final Select<? extends Record5<T1, T2, T3, T4, T5>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_lessThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Row6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_lessThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Record6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_lessThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Select<? extends Record6<T1, T2, T3, T4, T5, T6>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_lessThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Row7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_lessThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Record7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_lessThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Select<? extends Record7<T1, T2, T3, T4, T5, T6, T7>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_lessThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_lessThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Record8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_lessThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Select<? extends Record8<T1, T2, T3, T4, T5, T6, T7, T8>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_lessThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_lessThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_lessThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Select<? extends Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_lessThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_lessThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_lessThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Select<? extends Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_lessThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_lessThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_lessThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Select<? extends Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_lessThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_lessThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_lessThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Select<? extends Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_lessThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_lessThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_lessThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Select<? extends Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_lessThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_lessThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_lessThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Select<? extends Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_lessThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_lessThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_lessThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Select<? extends Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_lessThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_lessThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_lessThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Select<? extends Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_lessThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_lessThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_lessThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Select<? extends Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_lessThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_lessThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_lessThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Select<? extends Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_lessThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_lessThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_lessThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Select<? extends Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_lessThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_lessThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_lessThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Select<? extends Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_lessThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_lessThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_lessThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Select<? extends Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21>> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_lessThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_lessThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.lt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_lessThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Select<? extends Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22>> r2) {
    return r1.lt(r2);
  }

  public static <T extends Object> Condition operator_greaterThan(final Field<T> f1, final T f2) {
    return f1.gt(f2);
  }

  public static <T extends Object> Condition operator_greaterThan(final Field<T> f1, final Field<T> f2) {
    return f1.gt(f2);
  }

  public static <T extends Object> Condition operator_greaterThan(final Field<T> f1, final Select<? extends Record1<T>> f2) {
    return f1.gt(f2);
  }

  public static <T extends Object> Condition operator_greaterThan(final Field<T> f1, final QuantifiedSelect<? extends Record1<T>> f2) {
    return f1.gt(f2);
  }

  public static <T1 extends Object> Condition operator_greaterThan(final Row1<T1> r1, final Row1<T1> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object> Condition operator_greaterThan(final Row1<T1> r1, final Record1<T1> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object> Condition operator_greaterThan(final Row1<T1> r1, final Select<? extends Record1<T1>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_greaterThan(final Row2<T1, T2> r1, final Row2<T1, T2> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_greaterThan(final Row2<T1, T2> r1, final Record2<T1, T2> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_greaterThan(final Row2<T1, T2> r1, final Select<? extends Record2<T1, T2>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_greaterThan(final Row3<T1, T2, T3> r1, final Row3<T1, T2, T3> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_greaterThan(final Row3<T1, T2, T3> r1, final Record3<T1, T2, T3> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_greaterThan(final Row3<T1, T2, T3> r1, final Select<? extends Record3<T1, T2, T3>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_greaterThan(final Row4<T1, T2, T3, T4> r1, final Row4<T1, T2, T3, T4> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_greaterThan(final Row4<T1, T2, T3, T4> r1, final Record4<T1, T2, T3, T4> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_greaterThan(final Row4<T1, T2, T3, T4> r1, final Select<? extends Record4<T1, T2, T3, T4>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_greaterThan(final Row5<T1, T2, T3, T4, T5> r1, final Row5<T1, T2, T3, T4, T5> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_greaterThan(final Row5<T1, T2, T3, T4, T5> r1, final Record5<T1, T2, T3, T4, T5> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_greaterThan(final Row5<T1, T2, T3, T4, T5> r1, final Select<? extends Record5<T1, T2, T3, T4, T5>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_greaterThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Row6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_greaterThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Record6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_greaterThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Select<? extends Record6<T1, T2, T3, T4, T5, T6>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_greaterThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Row7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_greaterThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Record7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_greaterThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Select<? extends Record7<T1, T2, T3, T4, T5, T6, T7>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_greaterThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_greaterThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Record8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_greaterThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Select<? extends Record8<T1, T2, T3, T4, T5, T6, T7, T8>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_greaterThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_greaterThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_greaterThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Select<? extends Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_greaterThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_greaterThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_greaterThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Select<? extends Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_greaterThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_greaterThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_greaterThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Select<? extends Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_greaterThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_greaterThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_greaterThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Select<? extends Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_greaterThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_greaterThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_greaterThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Select<? extends Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_greaterThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_greaterThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_greaterThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Select<? extends Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_greaterThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_greaterThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_greaterThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Select<? extends Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_greaterThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_greaterThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_greaterThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Select<? extends Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_greaterThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_greaterThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_greaterThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Select<? extends Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_greaterThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_greaterThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_greaterThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Select<? extends Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_greaterThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_greaterThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_greaterThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Select<? extends Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_greaterThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_greaterThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_greaterThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Select<? extends Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_greaterThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_greaterThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_greaterThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Select<? extends Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21>> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_greaterThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_greaterThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.gt(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_greaterThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Select<? extends Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22>> r2) {
    return r1.gt(r2);
  }

  public static <T extends Object> Condition operator_lessEqualsThan(final Field<T> f1, final T f2) {
    return f1.le(f2);
  }

  public static <T extends Object> Condition operator_lessEqualsThan(final Field<T> f1, final Field<T> f2) {
    return f1.le(f2);
  }

  public static <T extends Object> Condition operator_lessEqualsThan(final Field<T> f1, final Select<? extends Record1<T>> f2) {
    return f1.le(f2);
  }

  public static <T extends Object> Condition operator_lessEqualsThan(final Field<T> f1, final QuantifiedSelect<? extends Record1<T>> f2) {
    return f1.le(f2);
  }

  public static <T1 extends Object> Condition operator_lessEqualsThan(final Row1<T1> r1, final Row1<T1> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object> Condition operator_lessEqualsThan(final Row1<T1> r1, final Record1<T1> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object> Condition operator_lessEqualsThan(final Row1<T1> r1, final Select<? extends Record1<T1>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_lessEqualsThan(final Row2<T1, T2> r1, final Row2<T1, T2> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_lessEqualsThan(final Row2<T1, T2> r1, final Record2<T1, T2> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_lessEqualsThan(final Row2<T1, T2> r1, final Select<? extends Record2<T1, T2>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_lessEqualsThan(final Row3<T1, T2, T3> r1, final Row3<T1, T2, T3> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_lessEqualsThan(final Row3<T1, T2, T3> r1, final Record3<T1, T2, T3> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_lessEqualsThan(final Row3<T1, T2, T3> r1, final Select<? extends Record3<T1, T2, T3>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_lessEqualsThan(final Row4<T1, T2, T3, T4> r1, final Row4<T1, T2, T3, T4> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_lessEqualsThan(final Row4<T1, T2, T3, T4> r1, final Record4<T1, T2, T3, T4> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_lessEqualsThan(final Row4<T1, T2, T3, T4> r1, final Select<? extends Record4<T1, T2, T3, T4>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_lessEqualsThan(final Row5<T1, T2, T3, T4, T5> r1, final Row5<T1, T2, T3, T4, T5> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_lessEqualsThan(final Row5<T1, T2, T3, T4, T5> r1, final Record5<T1, T2, T3, T4, T5> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_lessEqualsThan(final Row5<T1, T2, T3, T4, T5> r1, final Select<? extends Record5<T1, T2, T3, T4, T5>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_lessEqualsThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Row6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_lessEqualsThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Record6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_lessEqualsThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Select<? extends Record6<T1, T2, T3, T4, T5, T6>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_lessEqualsThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Row7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_lessEqualsThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Record7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_lessEqualsThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Select<? extends Record7<T1, T2, T3, T4, T5, T6, T7>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_lessEqualsThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_lessEqualsThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Record8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_lessEqualsThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Select<? extends Record8<T1, T2, T3, T4, T5, T6, T7, T8>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_lessEqualsThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_lessEqualsThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_lessEqualsThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Select<? extends Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_lessEqualsThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_lessEqualsThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_lessEqualsThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Select<? extends Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_lessEqualsThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_lessEqualsThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_lessEqualsThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Select<? extends Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_lessEqualsThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_lessEqualsThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_lessEqualsThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Select<? extends Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_lessEqualsThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_lessEqualsThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_lessEqualsThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Select<? extends Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_lessEqualsThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_lessEqualsThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_lessEqualsThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Select<? extends Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_lessEqualsThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_lessEqualsThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_lessEqualsThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Select<? extends Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_lessEqualsThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_lessEqualsThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_lessEqualsThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Select<? extends Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_lessEqualsThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_lessEqualsThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_lessEqualsThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Select<? extends Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_lessEqualsThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_lessEqualsThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_lessEqualsThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Select<? extends Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_lessEqualsThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_lessEqualsThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_lessEqualsThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Select<? extends Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_lessEqualsThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_lessEqualsThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_lessEqualsThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Select<? extends Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_lessEqualsThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_lessEqualsThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_lessEqualsThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Select<? extends Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21>> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_lessEqualsThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_lessEqualsThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.le(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_lessEqualsThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Select<? extends Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22>> r2) {
    return r1.le(r2);
  }

  public static <T extends Object> Condition operator_greaterEqualsThan(final Field<T> f1, final T f2) {
    return f1.ge(f2);
  }

  public static <T extends Object> Condition operator_greaterEqualsThan(final Field<T> f1, final Field<T> f2) {
    return f1.ge(f2);
  }

  public static <T extends Object> Condition operator_greaterEqualsThan(final Field<T> f1, final Select<? extends Record1<T>> f2) {
    return f1.ge(f2);
  }

  public static <T extends Object> Condition operator_greaterEqualsThan(final Field<T> f1, final QuantifiedSelect<? extends Record1<T>> f2) {
    return f1.ge(f2);
  }

  public static <T1 extends Object> Condition operator_greaterEqualsThan(final Row1<T1> r1, final Row1<T1> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object> Condition operator_greaterEqualsThan(final Row1<T1> r1, final Record1<T1> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object> Condition operator_greaterEqualsThan(final Row1<T1> r1, final Select<? extends Record1<T1>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_greaterEqualsThan(final Row2<T1, T2> r1, final Row2<T1, T2> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_greaterEqualsThan(final Row2<T1, T2> r1, final Record2<T1, T2> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object> Condition operator_greaterEqualsThan(final Row2<T1, T2> r1, final Select<? extends Record2<T1, T2>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_greaterEqualsThan(final Row3<T1, T2, T3> r1, final Row3<T1, T2, T3> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_greaterEqualsThan(final Row3<T1, T2, T3> r1, final Record3<T1, T2, T3> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object> Condition operator_greaterEqualsThan(final Row3<T1, T2, T3> r1, final Select<? extends Record3<T1, T2, T3>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_greaterEqualsThan(final Row4<T1, T2, T3, T4> r1, final Row4<T1, T2, T3, T4> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_greaterEqualsThan(final Row4<T1, T2, T3, T4> r1, final Record4<T1, T2, T3, T4> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object> Condition operator_greaterEqualsThan(final Row4<T1, T2, T3, T4> r1, final Select<? extends Record4<T1, T2, T3, T4>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_greaterEqualsThan(final Row5<T1, T2, T3, T4, T5> r1, final Row5<T1, T2, T3, T4, T5> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_greaterEqualsThan(final Row5<T1, T2, T3, T4, T5> r1, final Record5<T1, T2, T3, T4, T5> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object> Condition operator_greaterEqualsThan(final Row5<T1, T2, T3, T4, T5> r1, final Select<? extends Record5<T1, T2, T3, T4, T5>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_greaterEqualsThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Row6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_greaterEqualsThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Record6<T1, T2, T3, T4, T5, T6> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object> Condition operator_greaterEqualsThan(final Row6<T1, T2, T3, T4, T5, T6> r1, final Select<? extends Record6<T1, T2, T3, T4, T5, T6>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_greaterEqualsThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Row7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_greaterEqualsThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Record7<T1, T2, T3, T4, T5, T6, T7> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object> Condition operator_greaterEqualsThan(final Row7<T1, T2, T3, T4, T5, T6, T7> r1, final Select<? extends Record7<T1, T2, T3, T4, T5, T6, T7>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_greaterEqualsThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_greaterEqualsThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Record8<T1, T2, T3, T4, T5, T6, T7, T8> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object> Condition operator_greaterEqualsThan(final Row8<T1, T2, T3, T4, T5, T6, T7, T8> r1, final Select<? extends Record8<T1, T2, T3, T4, T5, T6, T7, T8>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_greaterEqualsThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_greaterEqualsThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object> Condition operator_greaterEqualsThan(final Row9<T1, T2, T3, T4, T5, T6, T7, T8, T9> r1, final Select<? extends Record9<T1, T2, T3, T4, T5, T6, T7, T8, T9>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_greaterEqualsThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_greaterEqualsThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object> Condition operator_greaterEqualsThan(final Row10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> r1, final Select<? extends Record10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_greaterEqualsThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_greaterEqualsThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object> Condition operator_greaterEqualsThan(final Row11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11> r1, final Select<? extends Record11<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_greaterEqualsThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_greaterEqualsThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object> Condition operator_greaterEqualsThan(final Row12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12> r1, final Select<? extends Record12<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_greaterEqualsThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_greaterEqualsThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object> Condition operator_greaterEqualsThan(final Row13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13> r1, final Select<? extends Record13<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_greaterEqualsThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_greaterEqualsThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object> Condition operator_greaterEqualsThan(final Row14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14> r1, final Select<? extends Record14<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_greaterEqualsThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_greaterEqualsThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object> Condition operator_greaterEqualsThan(final Row15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15> r1, final Select<? extends Record15<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_greaterEqualsThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_greaterEqualsThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object> Condition operator_greaterEqualsThan(final Row16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16> r1, final Select<? extends Record16<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_greaterEqualsThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_greaterEqualsThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object> Condition operator_greaterEqualsThan(final Row17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17> r1, final Select<? extends Record17<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_greaterEqualsThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_greaterEqualsThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object> Condition operator_greaterEqualsThan(final Row18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18> r1, final Select<? extends Record18<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_greaterEqualsThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_greaterEqualsThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object> Condition operator_greaterEqualsThan(final Row19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19> r1, final Select<? extends Record19<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_greaterEqualsThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_greaterEqualsThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object> Condition operator_greaterEqualsThan(final Row20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20> r1, final Select<? extends Record20<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_greaterEqualsThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_greaterEqualsThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object> Condition operator_greaterEqualsThan(final Row21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21> r1, final Select<? extends Record21<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21>> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_greaterEqualsThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_greaterEqualsThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r2) {
    return r1.ge(r2);
  }

  public static <T1 extends Object, T2 extends Object, T3 extends Object, T4 extends Object, T5 extends Object, T6 extends Object, T7 extends Object, T8 extends Object, T9 extends Object, T10 extends Object, T11 extends Object, T12 extends Object, T13 extends Object, T14 extends Object, T15 extends Object, T16 extends Object, T17 extends Object, T18 extends Object, T19 extends Object, T20 extends Object, T21 extends Object, T22 extends Object> Condition operator_greaterEqualsThan(final Row22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22> r1, final Select<? extends Record22<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22>> r2) {
    return r1.ge(r2);
  }

  public static Table<Record1<Integer>> operator_upTo(final Field<Integer> f1, final Integer f2) {
    return DSL.generateSeries(f1, DSL.value(f2));
  }

  public static Table<Record1<Integer>> operator_upTo(final Field<Integer> f1, final Field<Integer> f2) {
    return DSL.generateSeries(f1, f2);
  }

  public static <T extends Number> Field<T> operator_doubleLessThan(final Field<T> f1, final T f2) {
    return DSL.<T>shl(f1, f2);
  }

  public static <T extends Number> Field<T> operator_doubleLessThan(final Field<T> f1, final Field<T> f2) {
    return DSL.<T>shl(f1, f2);
  }

  public static <T extends Number> Field<T> operator_doubleGreaterThan(final Field<T> f1, final T f2) {
    return DSL.<T>shr(f1, f2);
  }

  public static <T extends Number> Field<T> operator_doubleGreaterThan(final Field<T> f1, final Field<T> f2) {
    return DSL.<T>shr(f1, f2);
  }

  public static <T extends Object> Condition operator_diamond(final Field<T> f1, final T f2) {
    return f1.ne(f2);
  }

  public static <T extends Object> Field<T> operator_elvis(final Field<T> f1, final T f2) {
    return DSL.<T>nvl(f1, f2);
  }

  public static <T extends Object> Field<T> operator_elvis(final Field<T> f1, final Field<T> f2) {
    return DSL.<T>nvl(f1, f2);
  }

  public static <T extends Object> Condition operator_spaceship(final Field<T> f1, final T f2) {
    return f1.isNotDistinctFrom(f2);
  }

  public static <T extends Object> Condition operator_spaceship(final Field<T> f1, final Field<T> f2) {
    return f1.isNotDistinctFrom(f2);
  }

  public static <T extends Number> Field<T> operator_plus(final Field<T> f1, final T f2) {
    return f1.add(f2);
  }

  public static <T extends Number> Field<T> operator_plus(final Field<T> f1, final Field<T> f2) {
    return f1.add(f2);
  }

  public static <T extends Number> Field<T> operator_minus(final Field<T> f1, final T f2) {
    return f1.sub(f2);
  }

  public static <T extends Number> Field<T> operator_minus(final Field<T> f1, final Field<T> f2) {
    return f1.sub(f2);
  }

  public static <T extends Number> Field<T> operator_multiply(final Field<T> f1, final T f2) {
    return f1.mul(f2);
  }

  public static <T extends Number> Field<T> operator_multiply(final Field<T> f1, final Field<T> f2) {
    return f1.mul(f2);
  }

  public static <T extends Number> Field<T> operator_divide(final Field<T> f1, final T f2) {
    return f1.div(f2);
  }

  public static <T extends Number> Field<T> operator_divide(final Field<T> f1, final Field<T> f2) {
    return f1.div(f2);
  }

  public static <T extends Number> Field<T> operator_modulo(final Field<T> f1, final T f2) {
    return f1.mod(f2);
  }

  public static <T extends Number> Field<T> operator_modulo(final Field<T> f1, final Field<T> f2) {
    return f1.mod(f2);
  }

  public static <T extends Number> Field<BigDecimal> operator_power(final Field<T> f1, final T f2) {
    return DSL.power(f1, f2);
  }

  public static <T extends Number> Field<BigDecimal> operator_power(final Field<T> f1, final Field<T> f2) {
    return DSL.power(f1, f2);
  }

  public static Condition operator_not(final Condition c) {
    return c.not();
  }

  public static <T extends Object> Field<T> operator_minus(final Field<T> f) {
    return f.neg();
  }
}
