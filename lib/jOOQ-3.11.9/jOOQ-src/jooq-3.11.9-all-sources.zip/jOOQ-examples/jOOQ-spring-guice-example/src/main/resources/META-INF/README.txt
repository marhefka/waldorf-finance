Thanks for downloading jOOQ.
Please visit http://www.jooq.org for more information.

This example was inspired by Marcin's nice blog post:
http://blog.uws.ie/2013/04/using-jooq-with-spring-transactions/

And by this jOOQ User Group thread here:
https://groups.google.com/forum/#!topic/jooq-user/L9lqjxXxv5s